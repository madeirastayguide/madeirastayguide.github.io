# Madeira Stay Guide - Website

Site oficial do Madeira Stay Guide, um guia digital para alojamentos na Madeira.

## Sobre o Projeto

O Madeira Stay Guide é uma solução completa que centraliza todas as informações necessárias para os hóspedes, melhorando a experiência de estadia e reduzindo a carga operacional dos anfitriões.

## Funcionalidades

- **Design Responsivo**: Otimizado para desktop e mobile
- **Navegação Intuitiva**: Menu fixo com smooth scrolling
- **Seções Informativas**: Sobre, problemas, soluções, planos e benefícios
- **Formulário de Contato**: Sistema de contacto integrado
- **Animações**: Efeitos visuais modernos e profissionais
- **SEO Otimizado**: Meta tags e estrutura otimizada para motores de busca

## Tecnologias Utilizadas

- HTML5
- CSS3 (com variáveis CSS e Flexbox/Grid)
- JavaScript (ES6+)
- Font Awesome (ícones)
- Google Fonts (Inter e Open Sans)

## Estrutura do Projeto

```
madeira-stay-guide-site/
├── index.html          # Página principal
├── css/
│   └── style.css       # Estilos principais
├── js/
│   └── script.js       # Funcionalidades JavaScript
├── images/             # Imagens do site
│   ├── logo.png
│   ├── hero-bg.jpg
│   ├── landscape.jpg
│   └── hotel.jpg
├── favicon.png         # Ícone do site
├── _redirects          # Configuração de redirects do Netlify
├── netlify.toml        # Configuração do Netlify
└── README.md           # Este ficheiro

```

## Deploy no Netlify

Este site está preparado para deploy automático no Netlify:

1. Faça upload de todos os ficheiros para um repositório Git
2. Conecte o repositório ao Netlify
3. O deploy será automático usando as configurações em `netlify.toml`

### Configurações do Netlify

- **Build Command**: Não necessário (site estático)
- **Publish Directory**: `.` (raiz do projeto)
- **Redirects**: Configurados em `_redirects`
- **Headers**: Configurados em `netlify.toml` para segurança e cache

## Funcionalidades JavaScript

- **Navegação Mobile**: Menu hamburger responsivo
- **Smooth Scrolling**: Navegação suave entre seções
- **Animações**: Efeitos fade-in ao fazer scroll
- **Formulário**: Validação e envio com feedback visual
- **Contadores**: Animação dos números nas estatísticas
- **Notificações**: Sistema de notificações para feedback do utilizador

## Personalização

### Cores (CSS Variables)
- `--primary-color`: #0066CC (Azul oceano)
- `--secondary-color`: #00A86B (Verde esmeralda)
- `--accent-color`: #FF6B35 (Laranja coral)
- `--dark-color`: #2C3E50 (Cinza escuro)
- `--light-color`: #F8F9FA (Cinza claro)

### Tipografia
- **Headings**: Inter (Google Fonts)
- **Body**: Open Sans (Google Fonts)

## Contacto

Para mais informações sobre o Madeira Stay Guide:
- Email: info@madeirastayguide.pt
- Website: www.madeirastayguide.pt

---

© 2025 Madeira Stay Guide. Todos os direitos reservados.

